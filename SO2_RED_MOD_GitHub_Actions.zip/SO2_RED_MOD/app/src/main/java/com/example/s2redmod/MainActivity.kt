package com.example.s2redmod

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 9, 11)
    private val panel = Color.rgb(22, 22, 26)
    private val red = Color.rgb(255, 52, 52)
    private val muted = Color.rgb(160, 160, 170)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildScreen()
    }

    private fun rounded(color: Int, radius: Float = 18f, stroke: Int = 0): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
            if (stroke != 0) setStroke(1, stroke)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(18))
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBlock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBlock.addView(text("SO2 RED MOD", 25f, Color.WHITE, true))
        titleBlock.addView(text("TRAINING MENU  •  ANDROID", 10f, red, true))
        top.addView(titleBlock, LinearLayout.LayoutParams(0, -2, 1f))
        val version = TextView(this).apply {
            text = "v1.0"
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(dp(12), dp(7), dp(12), dp(7))
            background = rounded(Color.rgb(50, 18, 20), 30f, red)
        }
        top.addView(version)
        content.addView(top)
        addSpace(content, 20)

        val notice = TextView(this).apply {
            text = "DEMO BUILD\\nЭто самостоятельный макет меню. Он не подключается к Standoff 2, не меняет игровой процесс и не обходит античит."
            textSize = 12f
            setTextColor(Color.rgb(235, 205, 205))
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(Color.rgb(42, 19, 21), 14f, Color.rgb(120, 38, 42))
        }
        content.addView(notice)
        addSpace(content, 18)

        section(content, "VISUAL TRAINING")
        feature(content, "ESP Preview", "Переключатель демонстрации подсветки на макете")
        feature(content, "Aim Trainer", "Тренировочный режим наведения без доступа к игре")
        feature(content, "Recoil Practice", "Визуальная симуляция контроля отдачи")
        feature(content, "Bunny Hop Practice", "Учебный таймер прыжков")
        addSpace(content, 14)
        section(content, "MENU SETTINGS")
        feature(content, "Red Accent", "Красная цветовая схема")
        feature(content, "Compact Mode", "Компактное отображение меню")
        feature(content, "Sound Effects", "Звуки переключателей")
        addSpace(content, 18)

        val reset = Button(this).apply {
            text = "RESET SETTINGS"
            setTextColor(Color.WHITE)
            textSize = 12f
            background = rounded(Color.rgb(55, 22, 24), 14f, red)
            setOnClickListener {
                Toast.makeText(this@MainActivity, "Настройки макета сброшены", Toast.LENGTH_SHORT).show()
                buildScreen()
            }
        }
        content.addView(reset, LinearLayout.LayoutParams(-1, dp(48)))
        addSpace(content, 14)
        content.addView(text("SO2 RED MOD  •  UI CONCEPT ONLY", 10f, muted).apply {
            gravity = Gravity.CENTER
        })

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "●  LOCAL DEMO     •     NO GAME CONNECTION"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(red)
            setPadding(0, dp(12), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun section(parent: LinearLayout, label: String) {
        parent.addView(text(label, 11f, red, true).apply {
            letterSpacing = 0.12f
            setPadding(dp(2), 0, 0, dp(8))
        })
    }

    private fun feature(parent: LinearLayout, name: String, description: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(12))
            background = rounded(panel, 15f, Color.rgb(47, 47, 54))
        }
        val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        labels.addView(text(name, 14f, Color.WHITE, true))
        labels.addView(text(description, 10f, muted))
        card.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = Switch(this).apply {
            text = ""
            buttonTintList = null
            isChecked = false
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            trackTintList = android.content.res.ColorStateList.valueOf(red)
            setOnCheckedChangeListener { _, checked ->
                Toast.makeText(
                    this@MainActivity,
                    if (checked) "$name: demo ON" else "$name: OFF",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        card.addView(toggle)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2))
        addSpace(parent, 9)
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }
}
