# SO2 RED MOD — Android UI Demo

Это исходный проект самостоятельного Android-приложения с красно-чёрным меню.
Переключатели демонстрируют состояние элементов интерфейса и **не взаимодействуют**
со Standoff 2: нет чтения памяти игры, внедрения кода, ESP по реальным игрокам,
автоматического прицеливания или обхода античита.

## Как собрать APK

1. Установи Android Studio на ПК.
2. Открой папку `SO2_RED_MOD` через **File → Open**.
3. Дождись синхронизации Gradle. При необходимости установи Android SDK 35.
4. Выбери **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

Требования: JDK 17, Android Gradle Plugin 8.6.1, Kotlin 2.0.21, Android SDK 35.
Минимальная версия Android — 6.0 (API 23).


## Сборка APK через GitHub Actions (без Android Studio)

1. Создай пустой репозиторий на GitHub.
2. Загрузи в него всё содержимое этой папки (включая скрытую папку `.github`).
3. Открой вкладку **Actions** в репозитории.
4. Запусти workflow **Build Android APK** через **Run workflow** либо сделай push в ветку `main`.
5. После завершения открой запуск workflow и скачай artifact **SO2-RED-MOD-debug-apk**.
6. Распакуй artifact — внутри будет `app-debug.apk`.

Примечание: GitHub Actions собирает демонстрационное приложение; оно не подключается к Standoff 2.
